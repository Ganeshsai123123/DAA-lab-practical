
import time

def find(parent, x):
    if parent[x] != x:
        parent[x] = find(parent, parent[x])
    return parent[x]


def kruskal(vertices, edges):
    parent = list(range(vertices))
    mst = []
    total_cost = 0

    # Sort edges by weight
    edges.sort(key=lambda x: x[2])

    for u, v, w in edges:
        root1 = find(parent, u)
        root2 = find(parent, v)

        if root1 != root2:
            mst.append((u, v, w))
            total_cost += w
            parent[root1] = root2

        if len(mst) == vertices - 1:
            break

    if len(mst) != vertices - 1:
        print("MST is not possible")
        return

    print("\nMinimum Spanning Tree:")
    for u, v, w in mst:
        print(u, "-", v, "Weight:", w)

    print("Minimum Cost:", total_cost)


# Main program
vertices = int(input("Enter number of vertices: "))
n = int(input("Enter number of edges: "))

edges = []

print("Enter source, destination and weight:")

for i in range(n):
    u, v, w = map(int, input().split())
    edges.append((u, v, w))

start = time.time()

kruskal(vertices, edges)

end = time.time()

print("Execution Time:", end - start, "seconds")
print("Time Complexity: O(E log E)")
print("Space Complexity: O(V + E)")


import time

def floyd_warshall(graph, n):
    dist = [row[:] for row in graph]

    for k in range(n):
        for i in range(n):
            for j in range(n):
                if dist[i][k] != float('inf') and dist[k][j] != float('inf'):
                    dist[i][j] = min(dist[i][j],
                                     dist[i][k] + dist[k][j])

    print("\nShortest Distance Matrix:")
    for i in range(n):
        for j in range(n):
            if dist[i][j] == float('inf'):
                print("INF", end=" ")
            else:
                print(dist[i][j], end=" ")
        print()


# Main program
n = int(input("Enter number of vertices: "))

graph = []

print("Enter adjacency matrix (use -1 for no edge):")

for i in range(n):
    row = list(map(int, input().split()))
    graph.append(row)

# Convert -1 into infinity
for i in range(n):
    for j in range(n):
        if graph[i][j] == -1:
            graph[i][j] = float('inf')

start = time.time()

floyd_warshall(graph, n)

end = time.time()

print("\nExecution Time:", end - start, "seconds")
print("Time Complexity: O(V^3)")
print("Space Complexity: O(V^2)")


import time

def tsp(graph, n):
    visited_all = (1 << n) - 1

    dp = {}

    def solve(city, visited):
        if visited == visited_all:
            return graph[city][0]

        if (city, visited) in dp:
            return dp[(city, visited)]

        ans = float('inf')

        for next_city in range(n):
            if not (visited & (1 << next_city)):
                cost = graph[city][next_city] + solve(
                    next_city,
                    visited | (1 << next_city)
                )
                ans = min(ans, cost)

        dp[(city, visited)] = ans
        return ans

    return solve(0, 1)


# Main program
n = int(input("Enter number of cities: "))

graph = []

print("Enter the cost matrix:")

for i in range(n):
    row = list(map(int, input().split()))
    graph.append(row)

start = time.time()

result = tsp(graph, n)

end = time.time()

print("\nMinimum travelling cost:", result)
print("Execution Time:", end - start, "seconds")
print("Time Complexity: O(n^2 * 2^n)")
print("Space Complexity: O(n * 2^n)")

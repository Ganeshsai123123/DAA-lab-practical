import time

n = int(input("Enter number of vertices: "))

print("Enter adjacency matrix (use 0 if no edge):")
graph = []

for i in range(n):
    row = list(map(int, input().split()))
    if len(row) != n:
        print("Error: Enter exactly", n, "values per row.")
        exit()
    graph.append(row)

start = time.perf_counter()

selected = [False] * n
selected[0] = True

total_cost = 0
edges = 0

print("\nEdges in Minimum Spanning Tree:")

while edges < n - 1:
    minimum = float('inf')
    x = -1
    y = -1

    for i in range(n):
        if selected[i]:
            for j in range(n):
                if not selected[j] and graph[i][j] > 0:
                    if graph[i][j] < minimum:
                        minimum = graph[i][j]
                        x = i
                        y = j

    if x == -1:
        print("MST is not possible: Graph is disconnected.")
        break

    print(x + 1, "--", y + 1, "Weight:", minimum)

    total_cost += minimum
    selected[y] = True
    edges += 1

end = time.perf_counter()

if edges == n - 1:
    print("\nMinimum Cost of MST:", total_cost)

print("Time Complexity: O(V^2)")
print("Execution Time:", round(end - start, 6), "seconds")